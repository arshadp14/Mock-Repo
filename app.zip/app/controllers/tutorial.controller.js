const db = require("../models");
const Tutorial = db.tutorial;
const Op = db.Sequelize.Op;

exports.create = (req, res) => {
   // Validate request
    // if (!req.body.title) {
    //   res.status(400).send({
    //     message: "Content can not be empty!"
    //   });
    //   return;
    // }
 console.log(req.body.name);
    // Create a Tutorial
    const tutorial = {
      name: req.body.name,
      description: req.body.description
    //   published: req.body.published ? req.body.published : false
    };

    console.log(name);
  
    // Save Tutorial in the database
    Tutorial.create(tutorial)
      .then(data => {
          console.log("IN ");
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the Tutorial."
        });
      });
  };

  exports.findAll = (req, res) => {
    // const title = req.query.title;
    // var condition = title ? { title: { [Op.like]: `%${title}%` } } : null;
  console.log("--------------------------------------hiiii");
    Tutorial.findAll()
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving tutorials."
        });
      });
  };

